"""
    Authentication DTO.
"""


class Auth:
    """
    Wrapper for authentication data.
    """

    def __init__(self):
        pass
